# Danger Zone Report Generator

A Streamlit app that accepts the monthly `TicketsizeWisePerformance.xlsb` workbook and generates `SummaryReport_DangerZones.xlsx` using the supplied `SummaryReport.xlsx` layout.

## Rules

- For `EFFICIENCY%`, reads the `AVG` column and selects the lowest regional value.
- For every other metric, reads the latest monthly column (Sep-26 in the supplied file) and selects the highest regional value.
- Each output cell contains the selected region and formatted value.

## Run

```bash
cd /home/ubuntu/danger_zone_app
python3 -m pip install -r requirements.txt
streamlit run app.py --server.address 0.0.0.0 --server.port 8501
```

Then open the displayed URL, upload the monthly `.xlsb`, click **Generate danger-zone Excel**, and download the result.
