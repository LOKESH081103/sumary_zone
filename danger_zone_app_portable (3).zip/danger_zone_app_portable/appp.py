from __future__ import annotations

import base64
from collections import Counter
import io
import re
from pathlib import Path
from typing import Any

import pandas as pd
import streamlit as st
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font, Alignment

TEMPLATE_PATH = Path(__file__).parent / "SummaryReport.xlsx"
REPORT_END_ROW = 27  # The supplied monthly input ends at LMF/Direct-%.

# Embedded copy of the supplied SummaryReport.xlsx so the app works even when
# the user runs only app.py and uploads the monthly XLSB file.
_EMBEDDED_TEMPLATE_B64 = """UEsDBBQABgAIAAAAIQAhjEY6cwEAAIwFAAATAAgCW0NvbnRlbnRfVHlwZXNdLnhtbCCiBAIooAACAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADEVMluwjAQvVfqP0S+VomBQ1VVBA5dji0S9ANMPCEW
iW15Bgp/34lZVFUsQiD1kiix5232TH+4aupkCQGNs7noZh2RgC2cNnaWi6/Je/okEiRltaqdhVysAcVwcH/Xn6w9YMLVFnNREfln
KbGooFGYOQ+WV0oXGkX8GWbSq2KuZiB7nc6jLJwlsJRSiyEG/Vco1aKm5G3FvzdKpsaK5GWzr6XKhfK+NoUiFiqXVv8hSV1ZmgK0
KxYNQ2foAyiNFQA1deaDYcYwBiI2hkIe5AxQ42WkW1cZV0ZhWBmPD2z9CEO7ctzVtu6TjyMYDclIBfpQDXuXq1p+uzCfOjfPToNc
Gk2MKGuUsTvdJ/jjZpTx1b2xkNZfBL5QR++fdBDfdZDxeX0UEeaMcaR1DXjr44+g55grFUCPibtodnMBv7FP6eDWHgXnkadHgMtT
2LVqW516BoJABvbNeujS7xl59FwdO7SzTYM+wC3jLB38AAAA//8DAFBLAwQUAAYACAAAACEAtVUwI/QAAABMAgAACwAIAl9yZWxz
Ly5yZWxzIKIEAiigAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AKySTU/DMAyG70j8h8j31d2QEEJLd0FIuyFUfoBJ3A+1jaMkG92/JxwQVBqDA0d/vX78ytvdPI3qyCH24jSsixIUOyO2d62Gl/px
dQcqJnKWRnGs4cQRdtX11faZR0p5KHa9jyqruKihS8nfI0bT8USxEM8uVxoJE6UchhY9mYFaxk1Z3mL4rgHVQlPtrYawtzeg6pPP
m3/XlqbpDT+IOUzs0pkVyHNiZ9mufMhsIfX5GlVTaDlpsGKecjoieV9kbMDzRJu/E/18LU6cyFIiNBL4Ms9HxyWg9X9atDTxy515
xDcJw6vI8MmCix+o3gEAAP//AwBQSwMEFAAGAAgAAAAhAAFGK1YSBAAAOAoAAA8AAAB4bC93b3JrYm9vay54bWysVm1P4zgQ/n7S
/YdcxFcTO69NRFnlVYdEdxF04U5Cqkzi0ogk7jkOLUL732+cpqXQ06nHHipJ7Zk8fmbmmUnPvqzrSntmoi15M9bJKdY11uS8KJvH
sf59mqGRrrWSNgWteMPG+gtr9S/nv/5ytuLi6YHzJw0AmnasL6RcBobR5gtW0/aUL1kDljkXNZWwFI9GuxSMFu2CMVlXhomxa9S0
bPQNQiCOweDzeZmzhOddzRq5ARGsohLot4ty2W7R6vwYuJqKp26Jcl4vAeKhrEr50oPqWp0HF48NF/ShgrDXxNHWAj4u/BMMF3N7
EpgOjqrLXPCWz+UpQBsb0gfxE2wQ8i4F68McHIdkG4I9l6qGO1bC/SQrd4flvoER/NNoBKTVayWA5H0SzdlxM/Xzs3lZsduNdDW6
XH6ltapUpWsVbWValJIVY92DJV+xdxuiW0ZdWYHV9HzL1I3znZyvhFawOe0qOQUhb+HBEZsWxsoThBFWkomGShbzRoIOh7h+VnM9
drzgoHDtmv3VlYJBY4G+IFa40jygD+0VlQutE9VYj4P77y2Ef18CCdGgij+xdnGf8FVTcWi0+z2F0sN2+A8apbkK3IDIN+w23z9m
AUiKYKvDKyk0+H6RXEItbugzVAbqXwyNewGpJ9asyUVAZq/E90M3tmPkWlGK7FFEUOiMXJS4fkoyd4T9NP4BwQg3yDnt5GIouoIe
6zZU+MA0oeutheCgK4s3Gq94+EPq/uGytf1QAavxdluyVfsmD7XU1ndlU/DVWEdEifrl/XLVG+/KQi4gSN82wWWz9zsrHxfAmGAl
JTVDFLOx/hrGWWhnvoUy7PmQgNBHkZ94KLHM0LOjxPGw2TMy9ij1gxSo9Xet6cV/09Uw0l5m32Ci0wo6oTf22dY1EajDxEVBVHD7
j02YFGUOs3PnDtNt5973h7E9DrqjbFihmg0O31sNFGbrqqlPrwSIchbCwFftl9PqRo19RQTr5x9Y/nYSnpDgZHJCnDNjDxBU9v4w
gMmhP9WtD8kn2PRVLGwtL1vZ36E1SsgosXHoYd9GOLUcyKhvopFtmSi2EzN1vDRJI0dJSr27gv9jgvcdGmxfiorlggo5FTR/glfp
NZtHtIUe6FNvAN99spEzirAFFO2MZMgmPkZR5NrISTLL8UgSp072RlaFP//k/BwZ/dOMyg5mixor/TpQ12zY3W3ONxtDXd+Ni+A6
UXkfnv43xxuIvmJHOme3RzrGXyfTyZG+l+l0dpcd6xxOoiQ83j+8vg7/nKZ/bI8w/jGhHwueENvHVhoiy4ptZHuZh0YZdpBle3bs
2FFKsPdW8GqVP3+u3qZtbBUZ7//EGeanqr8CD4bff1rL5GCCF14/8nulKvp9f+3Qzv8GAAD//wMAUEsDBBQABgAIAAAAIQBKqaZh
+gAAAEcDAAAaAAgBeGwvX3JlbHMvd29ya2Jvb2sueG1sLnJlbHMgogQBKKAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAC8ks1qxDAMhO+FvoPRvXGS/lDKOnsphb222wcwsRKHTWxjqT95+5qU7jawpJfQoyQ08zHMZvs59OIdI3XeKSiyHAS62pvOtQpe
909X9yCItTO69w4VjEiwrS4vNs/Ya05PZLtAIqk4UmCZw4OUVFscNGU+oEuXxsdBcxpjK4OuD7pFWeb5nYy/NaCaaYqdURB35hrE
fgzJ+W9t3zRdjY++fhvQ8RkLyYkLk6COLbKCafxeFlkCBXmeoVyT4cPHA1lEPnEcVySnS7kEU/wzzGIyt2vCkNURzQvHVD46pTNb
LyVzsyoMj33q+rErNM0/9nJW/+oLAAD//wMAUEsDBBQABgAIAAAAIQD78+JcOhkAAEGhAAAYAAAAeGwvd29ya3NoZWV0cy9zaGVl
dDEueG1spJRdb5swFIbvJ+0/IN8HMAHyoZAqbdJuUjdFS7tdO2ASq4CZ7TRJp/33HZuPZIpU0VYKMZjjx+85fg+Tq0OeWc9USMaL
CGHbRRYtYp6wYhOhx4fb3hBZUpEiIRkvaISOVKKr6edPkz0XT3JLqbKAUMgIbZUqx44j4y3NibR5SQt4k3KREwWPYuPIUlCSmEV5
5niuGzo5YQWqCGPRhcHTlMV0zuNdTgtVQQTNiAL9cstK2dDyuAsuJ+JpV/ZinpeAWLOMqaOBIiuPx183BRdknUHeB+yT2DoI+Hlw
9ZttzPzFTjmLBZc8VTaQnUrzZfojZ+SQuCVd5t8Jg31H0GemD/CE8t4nCQctyzvB+u+EhS1Ml0uMdyyJ0J/5fLgYLIKwN5rhYc/H
odub+bN+bzG4xou5615fh7d/0XRifLIU00lJNnRF1WO5FFbK1ANfwgR4FTnTidNGJQwMoYtgCZpGaIbH3zDu6xgT8pPRvTy7t+SW
7+8ES+5ZQcG94HtF1iua0VhRkImR9cJ5vopJRr9rD2cw50KU9v2a8ycN/AqBLkgtSUGt46oE95iVipf3NFU3NINVsxG0EIkVe6ZL
iIvQmivFcx1gWkvBVCr4Cy2MWKNAp6Gh/wdXkIp6h10oqvxtkjUPbTW0sqYy52nfmlaEIiY0JbtM3fDsF0vUNkIjGw9G4XAQoObd
D77/Qtlmq/PRTtDuHyfHOZUxtB1kbZvSxjyDosK/lTP9+YCuIQcz7isyxvYQh74besCW6qhbCcoR7ySUoN7dHGTLgN0MA8aa4Q1O
8mqEj6w1leq2rvcrOCiSwcHYSIJDPGFeWQqbmKUwNkv7F0rCzkqgAAYHY4M71QSy7ZgQbGgwg3NVge/V51dn1p0Hp2F4MDayhpdn
1p03qnkwfiRNDKdUeUn3XG2mwPaDPj6zUndZuPUm3DQ80Pjmeul2qISdHIoDe+CFwbnJ36CssSh8rVpl/keAjXFx2B+ezHvW5K39
9TfD9PA/AAAA//8AAAD//6yd624kuZGFX2XQD+BR3VXGzACraql4fYhGb2Nnf9hjTLe9u2+/VBUvEfFRggjYf2x/OBmZOiQz4zDV
yl++//7t24/PX358+e2XP//4n5/+/PXT5tNP3//x5e/fy//662ZX/s+vn7affvr6z+8//vjbyx9//u3Lj5vmfzf7L1//+p//9/nb
96/f/l7Yw192n3775etrif94rfHrp9Onnwr/Xui/fjtsf/n5X7/98vPXKnm6S85CsjlryYWSw15LPt8lmwdZ5lFrnqum/Fe/ms2D
1rzMNButuc405qdyM81O1/Ezjfm5wkxz0HXiTHPUmjTTnLQmTzT7MRQ/l2nR50aZCGpuvDsJXsVlqjzKWWA8fbpryiwbE8UMzWUi
MY5+vksOt4n28Jfz4bg9bHcP+/324fFxI36W2+R8rtclzrl9MBVfZhozRldq9sZ+N5EY9/3kTDsz0mGmMaeKk1OZhZBmZexkmGlG
HTUZXu8N8kbx7mS430jKZPi53QDuRA79ZmuG4ULNwY79XdLG/nF7PMv/GJee62Wo24XRvEw0RzMprzONmdtudi47+jONGbYw05hb
ZaRmuzXzNU3qbM0154nmPH52Nfz7leF/Fd/uBX3470QOv134VGDw75I2+KfD6fQg/mMMeK4XIQf/aG7gLzONmXLXieZsB3+mMefy
1Gz35lxhotnaB8HkXPYWkmY/l/EnzzTjXGrwDyuD/yrWg38neu2bq7lQg+G/S8bwn49y+I1Nz/Uy1PDbtT/RnO3wz+qYde1mdcwP
6KnZ7m0fMNOY+0OcnGtrplqa1DkYf/Lsmt9Y+8eV4X8V6+G/Ezn8W7v4KcHo3yXlqkdbZ5fGcz23GnPj3ws1W9sfXid1zsY/94Fz
+Q/UCR/QxMk1b23v94E6eaZ5Y8xLN//xx/2rWI/5nagxN/fMCyUY87ukrfjN9rCXK94UfK5XoTo9M2ovE83Gdv7UbI7mCewmdXZG
4yeavblzhMm5Hu3TfqLB6M80ttmbad5o9koX//HRfxXbzt/4/nTX6EeADYDUYELcJX1CHE+H9yZEvTB5OzjZKDjT2AlBzXZjo+BM
Y6PgTGMfAbPrMeeKszrG8DTRPJhbRp6cazeuR3UAJbl/fEK8ivXt4E7U8O/sM4AaDP9d0of/4Wgb/npmeQvY2If+TGOWynWmMQ8S
N9PYW8BEY599gZrNycycOKtjZmmaaDDik3Pthj9qxF93WT4+5De1HvOK9KDbh8BEhFGvmj7se5tjntvZ1Uo3K+tlKjLL5joRbff2
0T+tZKaZn4rs7X96Onv/n4qw9fM6XGUASqIfDdIOmz9VpTqkN5r+jd0afH8PsO4rich/K/DrJz0BzL3sMhFxAtxr9wlwOu3eu+3X
knIHcPtgnHiZiDYns8SvU5FtBaanM5X8TGTvgGEqMismTk9nrilNRfb2P/vpdm80BK/zauFu0DcD+wbArYCdDHYDaCLiZNDbf9vy
KH53Mky2uGxeeqnnVXvGj3YTaCqyGwEz0Rm3Bl7T5tEsjDCtZGZxnIlsH5qmF25Ol2ei/RvZ4Pae4MN7gfWtwqbsN4w7095uDVeV
Sgy4V9z3q6SG0+OuUTnRbtQ+t0uSV3S2QXEmerS7A1ORefK46elsqzARlYmtN+/DVIQ7xGx70MycNLsmm07y9MLfmhRLO4Svs+H1
cXUYO8QVqRlgrvoy0XAGtG1COd3wlmi202ZfC7SLlO2kWBO39wvXmehgxs1NK5lx8zPRDreFybadfecRJ5U29prSVGR3iKeicU26
Y1zaJixDf5sBRzEDuAlof/5LPez9e4DeKTw+ntVrAsyFyXbZFneDiejBDM61/UxywmzRL0x23uwk9pNKm0f7omgmsu9M41Rk0+Ls
wg+YC7MLfys9LO0ZburGlH5E4B3yZCMRHcQHdhLr2dQj4mBG6bldkhzKHW4Qk425PSbFRGTfj7vZ6TgpZpXwLnkiEqn+dtOKk9Nt
DnhETLYLD2Zd5Gmlt5rIpU3FTd2vko+IybaiuaBLPez9G0TbWGzt6XM7Wb8ZvYBcQRyIBwkgESSBZEn0TXZpa+71dfzrY1beZLnN
Zuf1pR72vodtL2542PaTGnlpp++uXkEciAcJIBEkgWRJtIdLu1mbummib07mVvBUVap7se+4Jhp2L22Pa9jaNm2GrZZc2zV2ox2I
BwkgESSBZEn0r4ss7Rht61aEWN4VKQ/tJvFEAw+rZlR+bicbyxvkCuJAPEgAiSAJJEuiPVzadNnWTRexvCuSHtq7/2WioYdtz6XP
w3Yy4WE9/Vje0DgQDxJAIkgCyZJoD5f2KrY1jOvlbZbuU1WpqWmaqMtEQ1vb7sWwtW0G9OXdrkjYajUOGg8SQCJIAsmSaFtfY+WH
U/+2hlC5vBnf8RKgHvbuk6dq5PJuiXd4aMm1XdC4RYJ4kAASQRJIlkR7uBSStzXryeV9R2p5Yx5Sw3nYQvKYhy1YDg8tubYLEh5a
jYcmgESQBJIl0R4uxcxtDS16edvXk1WllrfZtbtMNLS1Jc9hawtNw1ZLru0aha1W46EJIBEkgWRJtK1LiW1bs4Fc3oxeO/u6px72
/vK+15HLuwWR4aEl13ZBwkOr8dAEkAiSQLIk2sOlgLOtAUcubwYc8X7ult0u9bD3PUTAaScTT+/2+wDN1Ss0DsSDBJAIkkCyJNrD
pYCzrZmj/Czjd4rNyn2qInXTtDuLXdPc+FyJnIcIOO304lFtNQ4aDxJAIkgCyZJoD5cCzrbGidPYiatIOoalfD9q1w/6XA+ShiG6
tHMJw6zGQeNBAkgESSBZEmXYbim63NQlVQvDKlIPEPPvG7qkz7BKhGGt8lilIFcQB+JBAkgESSBZEm3YUk7Z1aAgDbsjtSatYU0y
DEMoaZWFYQgl0DgQDxJAIkgCyZJow5ZCya42/NKwO5KG2f2FepRYkpXIGYa40c41liSIA/EgASSCJJAsiTZsKW7sar8vDWPcsJ1y
PUoadj9IGoZs0c4lDLMaB40HCSARJIFkSbRhS9liVxt3aRhzg+2B61HSMASJVlksSQQJaByIBwkgESSBZEm0YUtBYldbcmkY31fZ
tqIeJQ1DRGiVhWGICNA4EA8SQCJIAsmSaMOWIsKu9t/SMEYEu31fj5KGIQ+0ysIw5AFoHIgHCSARJIFkSbRhS3lgVxtyaRjzgN0Q
rUdJw9D8t8rCMDT/0DgQDxJAIkgCyZJow5aa/11v/luH8FSRaiswxdobkNFX4F1GKy0cs439FRoH4kECSARJIFkS7dhSq7/rrb6I
S+ae9VRFykPMOnT/9Sj55ET3304vnpzo/qHxIAEkgiSQLInycL/U/d/UuvuvSPVm+Pdt9/cdYp3Wo4RjrfSYdSBXEAfiQQJIBEkg
WRLt2FL7v2f7X5FyzCbMrunrtBLpmO32X9rJxhwDcSAeJIBEkASSJdGOLfX/e/b/FSnH7C/Idc1wDO8bWmkxx2wkuELjQDxIAIkg
CSRLoh1bCgB7BoCKlGP290W6ZjiGBNBKC8dsv3+FxoF4kAASQRJIlkQ7tpQA9kwAFSnHbMjsmuEYIkArLRxDBIDGgXiQABJBEkiW
RDu2FAH2jAAVKcdsyuya4RgyQCstHEMGgMaBeJAAEkESSJZEO2YzwO+vfyCk3EHufzLEffvv/7qRTz+9+88F9j0cjEbkaBq1pyqS
5trfP7p0zTAXeaGdTJiLvACNA/EgASSCJJAsiTZ3KS/smRcqUo7Z1q1rhmMIDK20cAyBARoH4kECSARJIFkS7dhSYNgzMFQkHbN/
/uHSNcMxBIZWWjiGwACNA/EgASSCJJAsiXZsKTDs+W6gIuUYWjfEg3qUbN0QD9rJROuGeACNBwkgESSBZEmUY4eleHBT63hQkXLM
tm5d0+dYJcKxVnrMMZAriAPxIAEkgiSQLIl2bCkeHBgPKlKO2data4ZjeD3QSgvH8HoAGgfiQQJIBEkgWRLt2FI8ODAeVKQcw9/Y
aK8QhmOIB620cAzxABoH4kECSARJIFkS7dhSPDgwHlSkHLOtW9cMxxAPWmnhGOIBNA7EgwSQCJJAsiTasaV4cGA8qEg5Zt8QdM1w
DPGglRaOIR5A40A8SACJIAkkS6IdW4oHB8aDipRj9hVB1wzHEA9aaeEY4gE0DsSDBJAIkkCyJNqxf088OPDdQUXKStvads2wEmGg
lRZWIgxA40A8SACJIAkkS6KtXAoDB4aBiqRj9s9fXLpmOIYw0EoLxxAGoHEgHiSARJAEkiXRji2FgQPDQEXKMdvads1wDGGglRaO
IQxA40A8SACJIAkkS6IdWwoDB4aBipRjaG0RBupRsrVFGGgnG2EAxIF4kAASQRJIlkQ5dlwKAze1DgMVKcdsa9s1fY5VIhxrpccc
A7mCOBAPEkAiSALJkmjHlsLAkWGgIuWYbW27ZjiGMNBKC8cQBqBxIB4kgESQBJIl0Y4thYEjw0BFyjHb2nbNcAxhoJUWjiEMQONA
PEgAiSAJJEuiHVsKA0eGgYqUY7a17ZrhGMJAKy0cQxiAxoF4kAASQRJIlkQ7thQGjgwDFSnHbGvbNcMxhIFWWjiGMACNA/EgASSC
JJAsiXZsKQwcGQYqUo7Z303omuEYwkArLRxDGIDGgXiQABJBEkiWRDv27wkDx8m7go398+FPVaXctfmga4a7yAftbMJd5ANoHIgH
CSARJIFkSbS7S/ngyHxQkXTM/tGbS9cMx5APWmnhGPIBNA7EgwSQCJJAsiTasaV8cGQ+qEg5ZvNB1wzHkA9aaeEY8gE0DsSDBJAI
kkCyJNqxpXxwZD6oSDlm80HXDMfuhWS3i3zQTjbyAYgD8SABJIIkkCyJcuy0lA9uap0PKlKO2XzQNd2xSoRjrfSYYyBXEAfiQQJI
BEkgWRLt2FI+ODEfVKQcs/mga4ZjyAettHAM+QAaB+JBAkgESSBZEu3YUj44MR9UpByz+aBrhmPIB620cAz5ABoH4kECSARJIFkS
7dhSPjgxH1SkHLP5oGuGY8gHrbRwDPkAGgfiQQJIBEkgWRLt2FI+ODEfVKQcs/mga4ZjyAettHAM+QAaB+JBAkgESSBZEu3YUj44
MR9UpByz+aBrhmPIB620cAz5ABoH4kECSARJIFkS7ZjNB+/+ytCJ7wQqUo7Znr9rhmPo+Vtp4Rh6fmgciAcJIBEkgWRJtGNLPf+J
PX9F0jHxxY/7PzDumuEYev5WWjiGnh8aB+JBAkgESSBZEu3YUs9/Ys9fkXLM9vxdMxxDz99KC8fQ80PjQDxIAIkgCSRLoh1b6vlP
7PkrUo7Znr9rhmPo+Vtp4ZhNAVdoHIgHCSARJIFkSZRjj0s9/02te/6KlGO25++a7lgloudvpYdjIFcQB+JBAkgESSBZEu3YUs//
yJ6/IuWY7fm7ZjiGnr+VFo6h54fGgXiQABJBEkiWRDu21PM/suevSDlme/6uGY6h52+lhWPo+aFxIB4kgESQBJIl0Y4t9fyP7Pkr
Uo7Znr9rhmPo+Vtp4Rh6fmgciAcJIBEkgWRJtGNLPf8je/6KlGO25++a4Rh6/lZaOIaeHxoH4kECSARJIFkS7dhSz//Inr8i5Zjt
+btmOIaev5UWjqHnh8aBeJAAEkESSJZEO7bU8z/Otv7tFzSeqkqZiI/L3CuJf35Xj5KPT9v0v7Tzd1uvIA7EgwSQCJJAsiTaxKUY
8MgYUJF0bGP/2Pili8a8Qw5otcW8Qw6AxoF4kAASQRJIlkRbtpQDHpkDKtKW2SDQRcMyBIFWW1iGIACNA/EgASSCJJAsibZsKQg8
MghUpC2zSaCLhmVIAq22sAxJABoH4kECSARJIFkSZdl5KQnc1DoJVKQts1Ggi7pllYh7Was9LAO5gjgQDxJAIkgCyZJoy5aiwJlR
oCJtmc0CXTQsQxZotYVlyALQOBAPEkAiSALJkmjLlrLAmVmgIm2ZDQNdNCxDGGi1hWUIA9A4EA8SQCJIAsmSaMuWwsCZYaAibZlN
A100LEMaaLWFZUgD0DgQDxJAIkgCyZJoy5bSwJlpoCJtmY0DXTQsQxxotYVliAPQOBAPEkAiSALJkmjLluLAmXGgIm2ZzQNdNCxD
Hmi1hWXIA9A4EA8SQCJIAsmSaMuW8sCZ7wAq0pbZ7r+LhmV4CdBqC8vwEgAaB+JBAkgESSBZEm3ZUvd/ZvdfkbLMfgP30kXDMnT/
rbawDN0/NA7EgwSQCJJAsiTasqXu/8zuvyJtme3+u2hYhu6/1RaWofuHxoF4kAASQRJIlkRbttT9n9n9V6Qts91/Fw3L0P232sIy
dP/QOBAPEkAiSALJkijLSoRe+2Zm/QSC+INf9xLmO3kbfOXmdqJXVbetHSgiQEObYRxR+eJl+yZkq+WIytcsrSoQRaJElBUyBi6F
gc0D00BjetrhSxz1SGUgAkGvLw1EJKCqGGhVxUCLioEWFQMtKgZaVAwUyBi4FA02D8wGjWkDbTgYKjEDEQ96fWkgAgJVxUCrKgZa
VAy0qBhoUTHQomKgQMbApaCweWBSaEwbaKPCUAkDERZ6fWkg4gJVxUCrKgZaVAy0qBhoUTHQomKgQMbApdiweWBuaEwbiE8B1iPV
EkZ06PWlgQgPVBUDraoYaFEx0KJioEXFQIuKgQIZA5dCxOaBKaIxbSA+lFWPVAYiSPT60kBECaqKgVZVDLSoGGhRMdCiYqBFxUCB
jIFLkWLzULv8MiD9T8hvj/YDME0mPd3aT6ZdhkqsaiSNfkrpKbIGVcVTqyqeWlQ8tah4alHx1KLiqUDG06XMsXmoMWB0I0+NaQM5
Ke9HqkmJ3NHrSwORPKgqBlpVMdCiYqBFxUCLioEWFQMFMgYuJZDNQw0FysA70wbapNuOVAYihfT60kDkEKqKgVZVDLSoGGhRMdCi
YqBFxUCBjIFLeWTzUCOCMvDOtIF8MDeVWMLIJL2+NBCphKpioFUVAy0qBlpUDLSoGGhRMVAgbeDtM/If/2pz++q8NLAyZeDRpuBN
Vw0DK5LhpH/VvqnKJ9ltxigfYGc4ASofV2c4ASofTreq8pl0i7JCxsC1cNI+r64MvDfu2kB85roeKZdwRcpAmwuKgQwnQI6qYiDD
CVAxkOEEqBj4ZjhZ/Ih8+yS5MvDeuGsDEY/7d+TFDGQ46Z88FzOQ4QSqYiDDCVCgqhjIcAJUDHwznCx+eL19vlt+/XP2nXX8wbtN
VwkD7x2/moE2F5QZaFFZwhYVAy0qM9CiYqBFxUCLyhK2qBgo0H0J//z992/ffnz+8uPLb/8PAAD//wAAAP//bJBNboMwEIWvYs0B
CpjfIIyE2k0WXeUEbhjACrEt47RSTt8hUtJFZ+f3Ps/Mm+muGGZ8x3XdxNndbFSQ5dB3L1sEnBQMsh1qSP77TTtkkgNZWhGiXlzR
jtKSLcsJ8WQvatiaQzvIjCOSYsuCJSURdiNJK+XsnJzmFGy2irI1LCmIVA+S/F2677ye8VOH2dhNrDjR1dM3WYIIZl5eIjq/+zX5
Xy5Gd32qBfWIYVc5iMm5+BR0673zCePNC689hpO5o4IDiO2sV3rVKQgXDNqoo3FWwartSMwjiG8M0dC3D2+oN4VpzaggHMfHbZMf
Fy7bghj7XwAAAP//AwBQSwMEFAAGAAgAAAAhAEuEoAkABgAAoyYAABgAAAB4bC93b3Jrc2hlZXRzL3NoZWV0Mi54bWyck8lu2zAQ
hu8F+g4E79ptRxYsB/GGBugh6HqmqZFFWCRVkt4a9N07kmo7hS9GAC2UOPzmn+HPyeNR1mQPxgqtchr5ISWguC6E2uT0+7eVl1Ji
HVMFq7WCnJ7A0sfpxw+TgzZbWwE4ggRlc1o512RBYHkFkllfN6BwptRGMoefZhPYxgArukWyDuIwHAWSCUV7QmbuYeiyFBwWmu8k
KNdDDNTMoX5bicaeaZLfg5PMbHeNx7VsELEWtXCnDkqJ5NnzRmnD1jXWfYwGjJOjwSvGOzmn6f7fZJKCG2116XwkB73m2/LHwThg
/EK6rf8uTDQIDOxFu4FXVPw+SdHwwoqvsOSdsNEF1rbLZDtR5PR1uQpnYfIw89Lhw9gbxMOFl87nIy9dhmGcpMvZ4mH+h04nhcAd
bqsiBsqcPkXZUxQOaTCddA76IeBg34xJa8i11tt24hkThchomAJy+trgtqK5KXG6+Qylm0NdIxFLZNyJPbxgWE7X2jkt2/nO8g5/
lUb/BtXlhBowFtW0zP+De8gVan/1iuN2YXBR+3Z8Vr7qjseLIQWUbFe7L/rwCcSmauUO/CG2rfVdVpwWYDkaHsvyk64JXNcIwSeR
oj25aFh27N4HUbgqp0nop9FoEI5ixKzButW/JvCdxTp/9lFRp7GD/QUAAP//AAAA//+U2t1qGzEUBOBXCX6AZvUvBcdQyIsY19Cr
tMQhbd++mlzonC0e6FwUQjtMj1x92vVuj7fv1+v7y/n9fDq+/fj18PZ8CIeH28/z623+9DR//h3y+fL07c/L9Xa5vr4/H7YvqRxO
xwuyXxGewXR4mH9ym7/9cQrj+PhxOj5e5q9ZuXqj0jvDq7Bs9wvnX/r/g+4mjOl+Y1YaZ3iNSCYsSt8M22cY8/0Jq9I4w6sxkhGb
UjjDVhjuT9iVwhl2ayYbZyiNM2yNiSw6bNIen2nXSdYdNDcz7Trj/c8ySGaQdp1kj8Oq4Nu7iWxMyU3wcGIjK5foBG8nsSklO2GH
h32Wkp6w49PJwiU/wQNKbEoJUPCC2DEUJUBI27nBLg+Sn+j9JHJYRu2S4/nEQi5ikp7o9bDDKEp6kF6fZWJTSnqi1xMrWbikJ3o9
iZyYUdKDtC2cTSnpiTs95CSKkh6k7Qwm9y0SnrTDQxolO2lnhzRKdJKnQzAm7XbNyyG7PElwkF7/MmT7zBtb5ZbSuyG7J0lskF4z
kgtEktQgvRrJyZskNEibQzakhCZ5NIlMmSU1SK8pM7kNzBIbpK2SnGlZcoO0VZL7lizBQdoq2fcc7YuOl5MJ7yzRQdqmJL6zZAfp
VVnIvswSHqStku1LSU/2eirbl5Ke7PVUsi+LpAdpOyvJviySHqStkuzLIulB2irJviySHqStkuzLIulB2irJhadoTwq8nkquPEXS
g7RNSbZ6kfQgvSobe0Ii6SleT2NbXdJTvJ5GtnqV9CBtCydbvUp6kLZK9mxI0lO9nka2epX0IG1Tkq1eJT1IWyXZ6lXSg7RVkgtF
1R60eT2N6KmSHqTXlJ3oqZIepK2S6KmSHqStkuhpkh6krZLoaZIepK2S6GmSHqStkuhpkh6krZLoaZIepK2S6GmSHqStkuhpkh6k
rZLoadqD6t3XHvboW9LTvJ5B9DRJD9Jr4YPo6ZIepK2S6OmSHqStkujpkh6krZLo6ZIepK2S6OmSHqStkujpkh6krZLo6ZIepK2S
6OmSHqRXZdgIn6696dm96tnYyyPJT989bNsIoCEBQtqtnQgakiCkXSchNCRCSLtOYmhIhpB2nQTRkBAh7TqJoiEpQtp1EkZDYoS0
62SvIiVHY+coEEdDcoS0zRmIoyE5Qtp1svdnmwRpnhu7VvZyapMoBcTdrMRS2CRMn3HXSjSFTeL0GXetxFPYJFCfcdfKXqBuEqmA
uGv919Sj/T+RvwAAAP//AAAA//+yKUhMT/VNLErPzCtWyElNK7FVMtAzV1IoykzPgLFL8gvAoqZKCkn5JSX5uTBeRmpiSmoRiGes
pJCWn18C4+jb2eiX5xdlF2ekppbYAQAAAP//AwBQSwMEFAAGAAgAAAAhAPZgtEG4BwAAESIAABMAAAB4bC90aGVtZS90aGVtZTEu
eG1s7FrNjxu3Fb8HyP9AzF3WzOh7YTnQpzf27nrhlV3kSEmUhl7OcEBSuysUAQrn1EuBAmnRS4HeeiiKBmiABrnkjzFgI03/iDxy
Rprhioq9/kCSYncvM9TvPf7mvcfHN49z95OrmKELIiTlSdcL7vgeIsmMz2my7HpPJuNK20NS4WSOGU9I11sT6X1y7+OP7uIDFZGY
IJBP5AHuepFS6UG1KmcwjOUdnpIEfltwEWMFt2JZnQt8CXpjVg19v1mNMU08lOAY1D5aLOiMoIlW6d3bKB8xuE2U1AMzJs60amJJ
GOz8PNAIuZYDJtAFZl0P5pnzywm5Uh5iWCr4oev55s+r3rtbxQe5EFN7ZEtyY/OXy+UC8/PQzCmW0+2k/ihs14OtfgNgahc3auv/
rT4DwLMZPGnGpawzaDT9dphjS6Ds0qG70wpqNr6kv7bDOeg0+2Hd0m9Amf767jOOO6Nhw8IbUIZv7OB7ftjv1Cy8AWX45g6+Puq1
wpGFN6CI0eR8F91stdvNHL2FLDg7dMI7zabfGubwAgXRsI0uPcWCJ2pfrMX4GRdjAGggw4omSK1TssAziOJeqrhEQypThtceSnHC
JQz7YRBA6NX9cPtvLI4PCC5Ja17ARO4MaT5IzgRNVdd7AFq9EuTlN9+8eP71i+f/efHFFy+e/wsd0WWkMlWW3CFOlmW5H/7+x//9
9Xfov//+2w9f/smNl2X8q3/+/tW33/2UelhqhSle/vmrV19/9fIvf/j+H186tPcEnpbhExoTiU7IJXrMY3hAYwqbP5mKm0lMIkwt
CRyBbofqkYos4MkaMxeuT2wTPhWQZVzA+6tnFtezSKwUdcz8MIot4DHnrM+F0wAP9VwlC09WydI9uViVcY8xvnDNPcCJ5eDRKoX0
Sl0qBxGxaJ4ynCi8JAlRSP/GzwlxPN1nlFp2PaYzwSVfKPQZRX1MnSaZ0KkVSIXQIY3BL2sXQXC1ZZvjp6jPmeuph+TCRsKywMxB
fkKYZcb7eKVw7FI5wTErG/wIq8hF8mwtZmXcSCrw9JIwjkZzIqVL5pGA5y05/SGGxOZ0+zFbxzZSKHru0nmEOS8jh/x8EOE4dXKm
SVTGfirPIUQxOuXKBT/m9grR9+AHnOx191NKLHe/PhE8gQRXplQEiP5lJRy+vE+4vR7XbIGJK8v0RGxl156gzujor5ZWaB8RwvAl
nhOCnnzqYNDnqWXzgvSDCLLKIXEF1gNsx6q+T4iEMknXNbsp8ohKK2TPyJLv4XO8vpZ41jiJsdin+QS8boXuVMBidFB4xGbnZeAJ
hfIP4sVplEcSdJSCe7RP62mErb1L30t3vK6F5b83WWOwLp/ddF2CDLmxDCT2N7bNBDNrgiJgJpiiI1e6BRHL/YWI3leN2Mopt7AX
beEGKIyseiemyeuKnxMsBL/8eWqfD1b1uBW/S72zL68cXqty9uF+hbXNEK+SUwLbyW7iui1tbksb7/++tNm3lm8LmtuC5ragcb2C
fZCCpqhhoLwpWj2m8RPv7fssKGNnas3IkTStHwmvNfMxDJqelGlMbvuAaQSX+nlgAgu3FNjIIMHVb6iKziKcQn8oMF3MpcxVLyVK
uYS2kRk2/VRyTbdpPq3iYz7P2p2mv+RnJpRYFeN+AxpP2Ti0qlSGbrbyQc1vQ92wXZpW64aAlr0JidJkNomag0RrM/gaErpz9n5Y
dBws2lr9xlU7pgBqW6/AezeCt/Wu16hnjKAjBzX6XPspc/XGu9o579XT+4zJyhEArcVdT3c0172Pp58uC7U38LRFwjglCyubhPGV
KfBkBG/DeXSW++4/FXA39XWncKlFT5tisxoKGq32h/C1TiLXcgNLypmCJegS1ngIi85DM5x2vQX0jeEyTiF4pH73wmwJhy8zJbIV
/zapJRVSDbGMMoubrJP5J6aKCMRo3PX082/DgSUmiWTkOrB0f6nkQr3gfmnkwOu2l8liQWaq7PfSiLZ0dgspPksWzl+N+NuDtSRf
gbvPovklmrKVeIwhxBqtQHt3TiUcHwSZq+cUzsO2mayIv2s7U579rUOuIh9jlkY431LK2TyDmw1lS8fcbW1QusufGQy6a8LpUu+w
77ztvn6v1pYr9sdOsWlaaUVvm+5s+uF2+RKrYhe1WGW5+3rO7WySHQSqc5t4972/RK2YzKKmGe/mYZ2081Gb2nusCEq7T3OP3bab
hNMSb7v1g9z1qNU7xKawNIFvDs7LZ9t8+gySxxBOEVcsO+1mCdyZ0jI9Fca3Uz5f55dMZokm87kuSrNU/pgsEJ1fdb3QVTnmh8d5
NcASQJuaF1bYVtBZ7dmCerPLRbMFuxXOythr9aotvJXYHLNuhU1r0UVbXW1O1HWtbmbWDsue2qRhYym42rUitMkFhtI5O8zNci/k
mSuVV9pwhVaCdr3f+o1efRA2BhW/3RhV6rW6X2k3erVKr9GoBaNG4A/74edAT0Vx0Mi+fBjDaRBb598/mPGdbyDizYHXnRmPq9x8
41A13jffQATh/m8gwJFAKxwF9bAXDiqDYdCs1MNhs9Ju1XqVQdgchj3YtJvj3uceujDgoD8cjseNsNIcAK7u9xqVXr82qDTbo344
Dkb1oQ/gfPu5grcYnXNzW8Cl4XXvRwAAAP//AwBQSwMEFAAGAAgAAAAhANVbxDMoBAAA3RUAAA0AAAB4bC9zdHlsZXMueG1s5FhN
b9s4EL0v0P8g8K7oI5JrGZKK2ImAAt1ggWSBvdIyZROlSIGiE7uL/e87pCRbre3UjZ20QXOIRWo0fDNvOBxO/GFVMuuByJoKniDv
wkUW4bmYUT5P0N/3mT1EVq0wn2EmOEnQmtToQ/ruj7hWa0buFoQoC1TwOkELpaqR49T5gpS4vhAV4fCmELLECoZy7tSVJHhW649K
5viuO3BKTDlqNIzK/BglJZafl5Wdi7LCik4po2ptdCGrzEcf51xIPGUAdeUFOLdW3kD61kp2i5jZnXVKmktRi0JdgF5HFAXNyS7c
yIkcnG81gebnafJCx/W/sn0ln6kpcCR5oJo+lMaF4Kq2crHkKkEBANUuGH3m4pFn+hUw3Eqlcf3FesAMZjzkpHEumJCWAurAc2aG
45I0EleVErV1i6UUj1q2wCVl6+adrycM5a1wSYEAPeloMA2kNJ5qqddcsFssOsq4vVYdNOB0nUZ1Dc6hjG348jU1MJHGENiKSJ7B
wGqf79cVEMNhDza+NXLfkZ5LvPb8sPeBYxYEOoScwZ7vIiWElZupNGakUECWpPOF/lWigv9ToRTsizSeUTwXHDPNb/dF/0vIFZAW
EqQWsK2/iSpILYrqwLTdCz+IomAQRv7AHQbee9dEnKPXbpc+TZFBb8Cfpges74w/TVHjwN/Zf28xeN505G/Av1zktikAEllOGLvT
W/+fYpNV9FGzKiy+LLNSfZwlCBKAPhO6R0hh7WOTQZqBzix9bY3uvtroWXqtVbFZ4BAqHwDuQ+XBSdp+beGqYmt9mOpjshmNTTbd
jq8YnfOSNCJpjLuhtRCSfoFP9bGbw3vSHJSr4rCjDkECXz4F6TUgHO0VoPRHPX7QvG91eb2gOpq+22U5JTIzlemWthcm9RikO2Yf
g/ScXF++4g7Qpz3Sdw9F8x/YEYcgnmNHnBnSS+QNA1EnyZ2s0Q+wo3n8KVuht2dfM+CeSrlwWerOpl87jfR8B+G197g6OnkewQM4
4+xH35l3GYTQrw5RX8XPXUC8lVy1m+GtR4mre7IyJdTeVPaTEsR3XGrqUqhEe+XuV8Xupmy1dO8kQbe6wGA96qdLyuAKvKfQBZ2z
1bZ0dvWdXek2limqN6uAX2akwEum7jcvE7R9/pPM6LKEPdtK/UUfhDIqErR9/qTv9t5g0xmBxUu5nOgOkLbNdILkfJqgDP4mkywz
HYSeiGNkQBY4/FTDlR1+raWkCfr3Zvw+ur7JfHvojod2cElCOwrH13YYTMbX11nk+u7kv14v7oROnGkdQmnpBaOaQb9Otr5qbb/b
ziWoN2isNyYB7D523Y24Cj3Xzi5dzw4GeGgPB5ehnYWefz0IxjdhFvawh8/s2LmO5zW9Pw0+HClaEkZ5R3VHcH8WOIbhE0Y4HRPO
ti+b/g8AAP//AwBQSwMEFAAGAAgAAAAhAJ2JiAglBwAAGiAAABQAAAB4bC9zaGFyZWRTdHJpbmdzLnhtbJRZ3XLiNhS+70zfQcNM
dtzZWNjyL9mEjgHDUgykxklme7PDJm7CToAUw7a97Vv1dfokPZID2NaRyV6i75yjo0+fjo/E5c9/LZ/Jt3STLdarq4ZJjQZJV/fr
h8Xq8apxk/R1v0Gy7Xz1MH9er9Krxt9p1vi5/eMPl1m2JeC7yq4aT9vty0Wzmd0/pct5Rtcv6QqQ39eb5XwLPzePzexlk84fsqc0
3S6fm8ww3OZyvlg1yP16t9peNWwDptmtFn/s0m4+wlyn0b7MFu3LbdsydKd12dy2L5t8IB803xPSu+4phs+q45bxHjN/HZbMW7j5
67BkbuqshYeHzDHANXQfBaI0y4hpRNK6DJ1Jo3wDLrKX+T1sDDCcpZtvaaPNDN1yIiIx4OiOHNcxdNPApuPzyeMwplvI+GBDsOEg
ikgy7I7CZDb8LaxmNA6TeNidSUvlZE6m8ZjcBtGN5CW4PsIE3Qw9CmYJGU8nyUfSj6Z3uj5Lpt2RrArYn++y7Q3jsJvUxRRb+8aY
ue3pmHzN1ZBvWgtuVJiwaoBmjxvVRMHylTdKnOvqslRmhdlkEzRrlVltpOltGHPVBrNZmFTXPZlOSC+Mfq2Oz5JgEH428WGGD1uK
IHLWeXSmAiwZSKZJoFjC9GGRPc2J1rKp6Z79VE1iD/su9S0Z7iye5hvSJJOQaNH6T3K7ft4tUzlKTmI1eD8OZx+rg2G/P+wOw0n3
k3SQu0ESDqbxp6rLp6RHgttBdbh3EwfJcDqRpu1IkeHDQe6GsxDfZkF4DQ6fHiEPckE6wWQ0nEipFCwGyRQIi4bX1bQKNsOgDo2i
5LbGmcPva/DrIPk8rsHjcAJqqTNI4hp0FkRBPAyxD/GepBns13U8rAa5jqeDOBjnRO/ZkGc6O0320aSG7aMRSvcRxvku4wjhRwMF
40cDFeUFC4zzI6wmvWCDs847nhPqLZooCS0aIYQWYYzQKi4RWjRACS0a4ISWLGRCi7CK0JKNktCTEoUwb9BoyQrntF6lpQBoXShZ
qGg9JdRSkBgl9rRUS0EUFYK32ye0WjRRarVohPBahDGtVnFJq0UDlNSiAa7VkoVMaRFWabVkg2sVTE5qtWRTR2ltQS1FUZB6oqSW
QqhoPaXVUhBEqyW8htmTdbX0NTuUjdpv3mHDqlaD3df5Zr7VHIsyW+7Ceunz00KzfWohoLgeaTPWlbqy/M6pzSwZMm2HOgbpbqSe
SkzlUsOX0zhkiXaSo+gc2sRzctc5J8nsnIylFke0g6QzvZl0Q7mH7XeIobtwhevI/RzxdJMpINPSma3A3j1uP+Bgnim6eqLZHjVN
ef3cZyQ1Tte71df5l88m0SyPuogbJ6TOzWGUGfJsdxIP0bgPnWWvD20o3/Rq8hy+gFs58nYifFAkdxJKkcjoXxAU+O+ffy3TADEi
+nnVCNHAiN84wETSZcukPgcU7FvUMjE3cQqIxqjl18AOtTwlXJ1xvFt+mS/Iu/ny5QMZrOGa5NvUQ+5BNyMSp4/wZAYW+C6/Zucy
aiCHVNyjFOsFpkzKUKaKbFrURhfG3Q2buthu3HWI5ni0xTB5AeRTD0kWvOC+SFsO6gVuFjWR8hDOs61ugkKFv0ENWdT4+xXYV6nh
iVvACnouiOaa1G4psuMTYwIQIdHKJfJlFhRERUjAXNV0jB8EhZ8JMRGi8vkc6qkINl3aUuZioOSLmJZFDU+1Bg/0o8JacOQUmOVQ
A5cPHEWPOsibQp6LR5lqfVyyPmWonIUzGDDYYvRMCAMfaibC+v41wwECkQ3bw3BITSS3w1sI6BuhYw9/h7JfXarqfh0GibvoZh5w
0LmDkL/PBDjC9uawTJCtmiSiqU7KMT3Qr3p6+E5ChVcTJb4BcAR8XplUD0+5EWwXO2nEqHMyErxioR+Hw5I8h7aQIxn/Qhgveoy2
kEOyR01UVaOIU2khegOEaPDajpXCtgCZAwnLJ09gUP9aCLsCc21qIwqGZzr1tvI3PFA2UliEGxQ5D1mDwCAVTAi5n0tttFmCVGx8
6cLPtKmPiCvHHLRY5ZhLGfKFzjGfthDF55hHLaRY5WuAIqfixQKRIzGDa0G1h9ao/NlU86GVUT6q5hulenJVb2MeW5wbaAnQY7M3
8TyU4gPMqI/sXDKBlTFYNXISBMZrN8KkwPgFBjvJAoSybig6nT3OqIt+FpIZP57Q5mAJCwy+CMhJEn7QsllvbUbAoVquYUiz0bIh
ohsU/tlDKpwAoVtFm1kBis7PQPEbLi+oDlj/AJhmw5cD61OFG5xkRLEiJHxxLKRwjCEkbB1WbgJAgHdkw0cBL2/AO3KMc4waDsaM
AP0WdZBMBCaI8VBi9jj02ZYytrh8MNT/0FLzTh2Zn/8XFPbwfyJhXCfiilqD5xfVGoP8Qoob5LNLf1+EvbP9zFVx5hB+O84x/AJc
fMBvwn/77f8BAAD//wMAUEsDBBQABgAIAAAAIQA7bTJLwQAAAEIBAAAjAAAAeGwvd29ya3NoZWV0cy9fcmVscy9zaGVldDEueG1s
LnJlbHOEj8GKwjAURfcD/kN4e5PWhQxDUzciuFXnA2L62gbbl5D3FP17sxxlwOXlcM/lNpv7PKkbZg6RLNS6AoXkYxdosPB72i2/
QbE46twUCS08kGHTLr6aA05OSonHkFgVC7GFUST9GMN+xNmxjgmpkD7m2UmJeTDJ+Ysb0Kyqam3yXwe0L0617yzkfVeDOj1SWf7s
jn0fPG6jv85I8s+ESTmQYD6iSDnIRe3ygGJB63f2nmt9DgSmbczL8/YJAAD//wMAUEsDBBQABgAIAAAAIQBErn8WIAQAADASAAAn
AAAAeGwvcHJpbnRlclNldHRpbmdzL3ByaW50ZXJTZXR0aW5nczEuYmlu7FddcxRFFL33dG9P7yab3SSbkEA+NotJACUQDBo1wMZN
gCgGJEER0TLlRKWKClUKz25Z5YNvlg88UOV/8Df4J3zxn1jWenpm8gFqTCSoKXO7uqY/pu89c/v07TsNWZE1ucdalUuyyueqfC53
5GP2r8ldeSBfsHVDLsp1PhdY7vJ5RWY5WxURtTP4WZY7zU8qkLw8apvysahEchNhhG+wzMoUW3stSoWphfT5pP7Gytq9NQ76nmyG
C8KanBP51X7v5aO8/aa7sWsPPGknYGhFIg0zxabGaqDGWOTgYlW2S7ZMm9HWjjd5LWgb2lFEB0pGCmEWBskyRPDIB0VhRMMkqEet
5grUGSEyEV/0YQfafrdQKrEW4UUMq2XNVV01qkoxUZgZUOlY14+cOtuMbN3bupTCqK8aX7WPGaLhjki9kXK6LGBRpxzyXXlIJ1FI
V6y+CiPdAa6tGV+T1Zj+2DQEB65AHgXw201RO7RkyujULu3WCnrQi0PoM/04jCMYwCCGMIwqRlDDUTyHUYxhHMdwHCfwvL6gJ3VC
T+lpndQz+qJO6Vl9SV/GtL6CV/EaZnAO53EBdczq62jonG/O4yIu4TIWIAioXOJwWyOs4HFbsIRl60XTYUpa1k7ThW5UNMOFBJcd
sIN2yA474tKaHtUMlx7T43pCiQsn44n4VHwaj+HSaSS4zIye0/N6Qeua4cK8W4f1hn0TV/AWFnEV1/A2rvvaEpZxA+/gXdzEe7jl
W/o+buMDfAgxKdc290ITVmm7Jp4NX5B61vW4XnfI9UX90WE9ogM6qEM6bOKNT9DKqFbGtDKuFeHG+xH4TsllWx22Wcg7kI6+bH05
5bIhyU3OJL5T8Sm9lUN+xLnIeZd3Bdfm2l3RBYpzm9Hluo2Q2NRUpOt9f8p7Z3gkuSG0Fw5XfVqqIWxYtvMsU+TwozaRM+yHGrj9
GfuTX28/q/iKYegHqunrCwc/Tk5u0EopURU5G0oQqkvk29CdTWLgCmPd35MoaDaChztazqBxu7F4a2ny7MRCo7Eri3u4DkpBiGX7
RMJGlVhbrf2D+Rkj/Y76G3JVFnlfL8iczLO1zNYsb+ydytOuv5wZ2pOD1Gw2N3D/yDOVScT8ImJ44KW7M5ljWvMJL/oHPNL3mbgs
sX+f5Q4Tnk+Z4vyVbFj+J6jWlHZlxGIC1c44whgWPjaRX1qhiD5MwqTkknHmWXkKE49twfF0xyEzO5D1bDGh1iap/twxe+u0iElr
qrGyxWQy4tOJcKvtXrJ7bWNhJVxCf5wZPw0HqHMfXRIHbH8mHtg8EYELW2swF5i4Tr0wlzLzS7ZCDbKedR1sz3/JA7k03Q43a5K+
it/yP1EKfzo6qmM6nv3p9MrOyv9+k/mz+a/4IDulO7nitsWn0mJJ5DcAAAD//wMAUEsDBBQABgAIAAAAIQCikq0piwEAANMCAAAR
AAgBZG9jUHJvcHMvY29yZS54bWwgogQBKKAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACMkstOwzAURPdI/EPkvesk
5VGsNAiCKhCtqKAIxM6yL41Vx45sQ8nf46ZtCI8Fy2hmju6Mk51/VCp6B+uk0WOUDGIUgeZGSL0co8fFBI9Q5DzTgimjYYwacOg8
PzzIeE25sTC3pgbrJbgokLSjvB6j0vuaEuJ4CRVzg+DQQXw1tmI+fNolqRlfsSWQNI5PSAWeCeYZ2QBx3RHRDil4h6zfrGoBghNQ
UIH2jiSDhHx5PdjK/RlolZ6zkr6pQ6fduX224Fuxc3842RnX6/VgPWzPCPcn5Hk2fWirYqk3W3FAeSY45RaYNza/ZdaXcgUN09E9
LoxSwH3YO7rQTDVecoenF3NclKA1k/j6Dhc3k2KakR5js7dizs/C07xKEJdNfqNDIY2VWYErI4wDwCiWkd/OfXhuZciIPI3TE5zE
OD5dJDE9HtHk9KXL7U2hQTvYtgaIKExAt4PtladhcbWYoD4vPqLpGT0+C7wf+c0kW2C16/A/YpLSdEiPRj3iHpC3R3//DfNPAAAA
//8DAFBLAwQUAAYACAAAACEAIUZD1r0BAADIAwAAEAAIAWRvY1Byb3BzL2FwcC54bWwgogQBKKAAAQAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAACcU1FP2zAQfp/Ef8j8Tp0CQlPlGKGyiYcxqrWwR3Q4l8bCsSP7GjX79XMSkaaAJm1v57vzd999/iyu9pVJ
GvRBO5ux+SxlCVrlcm23GXvYfDv9wpJAYHMwzmLGWgzsSp58EivvavSkMSQRwoaMlUT1gvOgSqwgzGLZxkrhfAUUj37LXVFohTdO
7Sq0xM/S9JLjntDmmJ/WIyAbEBcN/S9o7lTHLzxu2joSluK6ro1WQHFLeaeVd8EVlHzdKzSCT4sisluj2nlNrUwFnx7FWoHBZQSW
BZiAgh8S4hahE20F2gcpGlo0qMj5JOjfUbYLljxDwI5OxhrwGixFWl3bcOhjUwfy8pfzL6FEpCB4bBiSfTjtncb6Qp71DTH4a+OA
9QMqzJOfYLf4LyPmH4/oOA67xtnHKmw0GQz3xQo8fSDK+VSUntogycByvasq8O3TfXQnmPhMBy3G6A7Ja3W0xFh7c//zymtLT9ce
4Z2s/UtF9m/4Ll1Vg21jYYy+a/sSHuqNuwHCVxccJ8W6BI95NM7okjEhbqMBvOlAlmWnf/7a877QefZx+JhyfjlLz9Nox0lO8MMX
lH8AAAD//wMAUEsBAi0AFAAGAAgAAAAhACGMRjpzAQAAjAUAABMAAAAAAAAAAAAAAAAAAAAAAFtDb250ZW50X1R5cGVzXS54bWxQ
SwECLQAUAAYACAAAACEAtVUwI/QAAABMAgAACwAAAAAAAAAAAAAAAACsAwAAX3JlbHMvLnJlbHNQSwECLQAUAAYACAAAACEAAUYr
VhIEAAA4CgAADwAAAAAAAAAAAAAAAADRBgAAeGwvd29ya2Jvb2sueG1sUEsBAi0AFAAGAAgAAAAhAEqppmH6AAAARwMAABoAAAAA
AAAAAAAAAAAAEAsAAHhsL19yZWxzL3dvcmtib29rLnhtbC5yZWxzUEsBAi0AFAAGAAgAAAAhAPvz4lw6GQAAQaEAABgAAAAAAAAA
AAAAAAAASg0AAHhsL3dvcmtzaGVldHMvc2hlZXQxLnhtbFBLAQItABQABgAIAAAAIQBLhKAJAAYAAKMmAAAYAAAAAAAAAAAAAAAA
ALomAAB4bC93b3Jrc2hlZXRzL3NoZWV0Mi54bWxQSwECLQAUAAYACAAAACEA9mC0QbgHAAARIgAAEwAAAAAAAAAAAAAAAADwLAAA
eGwvdGhlbWUvdGhlbWUxLnhtbFBLAQItABQABgAIAAAAIQDVW8QzKAQAAN0VAAANAAAAAAAAAAAAAAAAANk0AAB4bC9zdHlsZXMu
eG1sUEsBAi0AFAAGAAgAAAAhAJ2JiAglBwAAGiAAABQAAAAAAAAAAAAAAAAALDkAAHhsL3NoYXJlZFN0cmluZ3MueG1sUEsBAi0A
FAAGAAgAAAAhADttMkvBAAAAQgEAACMAAAAAAAAAAAAAAAAAg0AAAHhsL3dvcmtzaGVldHMvX3JlbHMvc2hlZXQxLnhtbC5yZWxz
UEsBAi0AFAAGAAgAAAAhAESufxYgBAAAMBIAACcAAAAAAAAAAAAAAAAAhUEAAHhsL3ByaW50ZXJTZXR0aW5ncy9wcmludGVyU2V0
dGluZ3MxLmJpblBLAQItABQABgAIAAAAIQCikq0piwEAANMCAAARAAAAAAAAAAAAAAAAAOpFAABkb2NQcm9wcy9jb3JlLnhtbFBL
AQItABQABgAIAAAAIQAhRkPWvQEAAMgDAAAQAAAAAAAAAAAAAAAAAKxIAABkb2NQcm9wcy9hcHAueG1sUEsFBgAAAAANAA0AbAMA
AJ9LAAAAAA=="""

def get_template_bytes() -> bytes:
    if TEMPLATE_PATH.exists():
        return TEMPLATE_PATH.read_bytes()
    return base64.b64decode(_EMBEDDED_TEMPLATE_B64)

TICKET_SIZES = [
    "Less 10L", "10-20L", "20-35L", "35-50L",
    "50-100L", "100-200L", "200-300L", "Gr 300L",
]

# Output labels that intentionally differ from the source workbook labels.
ALIASES = {
    "1-29 (S2C)": ["1-29"],
    "60-89 (S3C)": ["60-89"],
    "1-29 NORM VALUE": ["1-29 Norm (Crs)", "1-29 Norm Value"],
    "1-29 NORM VALUE %": ["1-29 Norm%", "1-29 Norm Value %"],
    "FRESH BOUNCE %": ["Fresh Overall Bounce %", "FB%"],
    "FB 0-6 MOB": ["0-6 MOB", "FB 0-6%"],
    "FB 7-12 MOB": ["7-12 MOB", "FB 7-12%"],
    "FB 13-24 MOB": ["13-24 MOB", "FB 13-24%"],
    "FB >24 MOB": ["Grt 24 MOB", "FB >24%"],
    "1-29-LAST MONTH FLOW--STOCK": ["1-29-Last Month Flow--Stock"],
    "1-29-LAST MONTH FLOW": ["1-29-Last Month Flow"],
    "1-29-LAST MONTH FLOW %": ["1-29-Last Month Flow %"],
    "30-59-LAST MONTH FLOW--STOCK": ["30-59-Last Month Flow--Stock"],
    "30-59-LAST MONTH FLOW": ["30-59-Last Month Flow"],
    "30-59-LAST MONTH FLOW %": ["30-59-Last Month Flow %"],
    "30-59-DIRECT FLOW--STOCK": ["30-59-Direct Flow--Stock"],
    "30-59-DIRECT FLOW": ["30-59-Direct Flow"],
    "30-59-DIRECT FLOW %": ["30-59-Direct Flow %"],
    "60-89-LAST MONTH FLOW--STOCK": ["60-89-Last Month Flow--Stock"],
    "60-89-LAST MONTH FLOW": ["60-89-Last Month Flow"],
    "60-89-LAST MONTH FLOW %": ["60-89-Last Month Flow %"],
    "60-89-DIRECT FLOW--STOCK": ["60-89-Direct Flow--Stock"],
    "60-89-DIRECT FLOW": ["60-89-Direct Flow"],
    "60-89-DIRECT FLOW %": ["60-89-Direct Flow %"],
}


def norm(value: Any) -> str:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ""
    s = str(value).upper().strip()
    s = s.replace("–", "-").replace("—", "-")
    s = re.sub(r"\([^)]*\)", "", s)
    return re.sub(r"[^A-Z0-9]+", "", s)


def numeric(value: Any) -> float | None:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return None
    if isinstance(value, str):
        if value.strip() in {"", "-"} or value.strip().lower().startswith("0x"):
            return None
        value = value.replace(",", "")
    try:
        result = float(value)
        return result if pd.notna(result) else None
    except (TypeError, ValueError):
        return None


def format_value(value: float, metric: str) -> str:
    m = metric.upper()
    if "%" in m or "EFFICIENCY" in m or "BOUNCE" in m or "NORM VALUE %" in m or "FLOW %" in m or "ASSET" in m and "%" in m:
        return f"{value:.2%}"
    if "NORM VALUE" in m or "CRS" in m:
        return f"{value:,.2f} Cr"
    return f"{value:,.2f}"


def display_region(value: str) -> str:
    s = re.sub(r"_REGION$", "", str(value).strip(), flags=re.IGNORECASE)
    s = s.replace("_", " ")
    if s.upper() in {"NE", "WB", "RJ", "TS", "UP", "MP", "KA", "KL", "TN", "PHC", "ROMH"}:
        return s.upper()
    return s.title()


def source_column_map(df: pd.DataFrame) -> dict[str, dict[str, int]]:
    # Build both mappings: AVG and the latest monthly column. Header labels are
    # merged in the XLSB, so carry the last non-empty metric label across its
    # monthly columns. The latest numeric Excel date is Sep-26 in the supplied
    # workbook (and will naturally roll forward for later monthly files).
    result: dict[str, dict[str, int]] = {}
    current_label = ""
    latest_date = -1
    for col in range(df.shape[1]):
        label = df.iat[1, col] if df.shape[0] > 1 else None
        period = df.iat[2, col] if df.shape[0] > 2 else None
        if pd.notna(label) and str(label).strip():
            current_label = str(label).strip()
        if not current_label:
            continue
        key = norm(current_label)
        result.setdefault(key, {})
        if norm(period) == "AVG":
            result[key].setdefault("avg", col)
        else:
            try:
                serial = float(period)
            except (TypeError, ValueError):
                serial = -1
            if serial > 40000 and serial > latest_date:
                latest_date = serial
    # Second pass selects the last monthly column within each metric group.
    current_label = ""
    for col in range(df.shape[1]):
        label = df.iat[1, col] if df.shape[0] > 1 else None
        period = df.iat[2, col] if df.shape[0] > 2 else None
        if pd.notna(label) and str(label).strip():
            current_label = str(label).strip()
        if not current_label:
            continue
        try:
            serial = float(period)
        except (TypeError, ValueError):
            serial = -1
        if serial == latest_date:
            result.setdefault(norm(current_label), {})["latest"] = col
    return result


def find_source_col(metric: str, cmap: dict[str, dict[str, int]], mode: str = "avg") -> int | None:
    candidates = [metric] + ALIASES.get(metric.upper(), [])
    for candidate in candidates:
        if norm(candidate) in cmap and mode in cmap[norm(candidate)]:
            return cmap[norm(candidate)][mode]
    # Helpful fallback for minor label punctuation/casing changes.
    target = norm(metric)
    for key, cols in cmap.items():
        if target and (target in key or key in target):
            if mode in cols:
                return cols[mode]
    return None


def section_rows(df: pd.DataFrame) -> dict[str, list[int]]:
    sections: dict[str, list[int]] = {}
    current = None
    for i in range(3, len(df)):
        a = df.iat[i, 0] if df.shape[1] else None
        b = df.iat[i, 1] if df.shape[1] > 1 else None
        if norm(a) == "ATS":
            current = str(b).strip() if pd.notna(b) else None
            if current:
                sections.setdefault(norm(current), [])
        elif norm(a) == "ALL":
            current = "ALL TICKETSIZE"
            sections.setdefault(norm(current), []).append(i)
        elif current and norm(a) == "REGION":
            sections[norm(current)].append(i)
    return sections


def output_rows(template_ws):
    for row in range(2, template_ws.max_row + 1):
        metric = template_ws.cell(row, 2).value
        if metric not in (None, ""):
            yield row, str(metric).strip(), str(template_ws.cell(row, 1).value or "").strip()


def build_report(input_bytes: bytes, template_bytes: bytes) -> tuple[bytes, pd.DataFrame]:
    input_df = pd.read_excel(io.BytesIO(input_bytes), sheet_name="Summary", engine="pyxlsb", header=None)
    cmap = source_column_map(input_df)
    sections = section_rows(input_df)
    if not sections:
        raise ValueError("No ATS sections or REGION rows were found in the Summary sheet.")

    wb = load_workbook(io.BytesIO(template_bytes))
    ws = wb["Summary_Overall"]
    audit = []

    # The template contains additional asset/ED example sections that are not
    # present in this monthly XLSB. Clear their example values before writing.
    for clear_row in range(REPORT_END_ROW + 1, ws.max_row + 1):
        for clear_col in range(4, 14):
            ws.cell(clear_row, clear_col).value = ""

    for out_row, metric, category in output_rows(ws):
        if out_row > REPORT_END_ROW:
            continue
        source_mode = "avg" if "EFFICIENCY" in category.upper() else "latest"
        source_col = find_source_col(metric, cmap, source_mode)
        if source_col is None:
            # The supplied monthly workbook currently ends at LMF/Direct-%.
            # Keep the template labels below that point, but leave unsupported
            # sections blank instead of displaying a confusing error message.
            for out_col in range(4, 14):
                ws.cell(out_row, out_col).value = ""
            continue

        is_efficiency = "EFFICIENCY" in category.upper()
        direction = "LOWEST" if is_efficiency else "HIGHEST"
        selected_regions = []
        for idx, ticket in enumerate(["ALL TICKETSIZE"] + TICKET_SIZES, start=4):
            rows = sections.get(norm(ticket), [])
            candidates = []
            if ticket == "ALL TICKETSIZE":
                # Use the workbook's explicit ALL / ALL TICKETSIZE row.
                for r in rows:
                    value = numeric(input_df.iat[r, source_col])
                    if value is not None:
                        candidates.append(("ALL TICKETSIZE", value))
            else:
                for r in rows:
                    region = input_df.iat[r, 1] if input_df.shape[1] > 1 else None
                    value = numeric(input_df.iat[r, source_col])
                    if pd.notna(region) and value is not None:
                        candidates.append((str(region).strip(), value))
            if not candidates:
                ws.cell(out_row, idx).value = ""
                continue
            chosen = min(candidates, key=lambda x: x[1]) if is_efficiency else max(candidates, key=lambda x: x[1])
            shown_region = display_region(chosen[0])
            shown_metric = f"{metric} {category}" if is_efficiency else metric
            ws.cell(out_row, idx).value = format_value(chosen[1], shown_metric) if ticket == "ALL TICKETSIZE" else f"{shown_region} ({format_value(chosen[1], shown_metric)})"
            if ticket != "ALL TICKETSIZE":
                selected_regions.append(shown_region)
            audit.append({"Category": category, "Metric": metric, "Ticket Size": ticket, "Region": shown_region, "Value": chosen[1], "Rule": direction})
        # OVERALL is the mode of the eight ticket-size danger-zone regions.
        ws.cell(out_row, 13).value = Counter(selected_regions).most_common(1)[0][0] if selected_regions else ""

    # Make the generated report easier to scan without changing the template structure.
    red_fill = PatternFill("solid", fgColor="FCE4D6")
    green_fill = PatternFill("solid", fgColor="E2F0D9")
    for row, metric, category in output_rows(ws):
        fill = red_fill if "EFFICIENCY" in category.upper() else green_fill
        for col in range(4, 14):
            ws.cell(row, col).fill = fill
            ws.cell(row, col).alignment = Alignment(wrap_text=True, vertical="center")
        ws.cell(row, 2).font = Font(bold=True)

    ws.freeze_panes = "D2"
    ws.auto_filter.ref = ws.dimensions
    output = io.BytesIO()
    wb.save(output)
    return output.getvalue(), pd.DataFrame(audit)


st.set_page_config(page_title="Danger Zone Report", page_icon="", layout="wide")
st.title("Danger Zone Report Generator")
st.caption("Upload the monthly TicketsizeWisePerformance.xlsb file and download the region-level danger-zone report.")

with st.sidebar:
    st.header("Rules applied")
    st.markdown("- `Efficiency%`: uses the `AVG` column and selects the **lowest** region.\n- All other metrics: use the latest monthly column (Sep-26 for this file) and select the **highest** region.\n- Displays the region and value for each ticket-size bucket.")
    st.info("The app uses the supplied SummaryReport.xlsx as the output template.")

uploaded = st.file_uploader("Upload monthly input workbook (.xlsb)", type=["xlsb"])
if uploaded:
    if st.button("Generate danger-zone Excel", type="primary"):
        try:
            template_bytes = get_template_bytes()
            report_bytes, audit = build_report(uploaded.getvalue(), template_bytes)
            st.session_state["report_bytes"] = report_bytes
            st.session_state["audit"] = audit
            st.success(f"Report generated with {len(audit)} selected region/metric results.")
        except Exception as exc:
            st.error(f"Could not generate the report: {exc}")
            st.exception(exc)

if "report_bytes" in st.session_state:
    st.download_button(
        "Download SummaryReport_DangerZones.xlsx",
        data=st.session_state["report_bytes"],
        file_name="SummaryReport_DangerZones.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
    audit = st.session_state.get("audit")
    if audit is not None and not audit.empty:
        st.subheader("Preview of selected danger zones")
        st.dataframe(audit.head(50), use_container_width=True, hide_index=True)
else:
    st.info("Upload a workbook to begin.")
